from __future__ import annotations

from stark.contracts import IntervalLike, State
from stark.schemes.execution.executor import SchemeExecutor
from stark.schemes.monitoring.monitor import MonitorSchemeLike
from stark.schemes.monitoring.decorators import with_adaptive_step_monitoring
from stark.schemes.adaptivity import (
    SchemeStepControl,
    adaptive_adaptivity,
)
from stark.schemes.imex._support import (
    imex_display_resolvent_problem,
    imex_snapshot_state,
)
from stark.schemes.display.decorators import with_scheme_display
from stark.schemes.method.descriptor import SchemeDescriptor
from stark.schemes.method.tableau import ButcherTableau, ButcherTableauImex
from stark.schemes.imex.adaptive._kennedy_carpenter import SchemeKennedyCarpenterAdaptive


ARK436L2SA_EXPLICIT = ButcherTableau(
    c=(0.0, 0.5, 83.0 / 250.0, 31.0 / 50.0, 17.0 / 20.0, 1.0),
    a=(
        (),
        (0.5,),
        (13861.0 / 62500.0, 6889.0 / 62500.0),
        (-116923316275.0 / 2393684061468.0, -2731218467317.0 / 15368042101831.0, 9408046702089.0 / 11113171139209.0),
        (-451086348788.0 / 2902428689909.0, -2682348792572.0 / 7519795681897.0, 12662868775082.0 / 11960479115383.0, 3355817975965.0 / 11060851509271.0),
        (647845179188.0 / 3216320057751.0, 73281519250.0 / 8382639484533.0, 552539513391.0 / 3454668386233.0, 3354512671639.0 / 8306763924573.0, 4040.0 / 17871.0),
    ),
    b=(82889.0 / 524892.0, 0.0, 15625.0 / 83664.0, 69875.0 / 102672.0, -2260.0 / 8211.0, 0.25),
    order=4,
    b_embedded=(4586570599.0 / 29645900160.0, 0.0, 178811875.0 / 945068544.0, 814220225.0 / 1159782912.0, -3700637.0 / 11593932.0, 61727.0 / 225920.0),
    embedded_order=3,
)
ARK436L2SA_IMPLICIT = ButcherTableau(
    c=(0.0, 0.5, 83.0 / 250.0, 31.0 / 50.0, 17.0 / 20.0, 1.0),
    a=(
        (),
        (0.25, 0.25),
        (8611.0 / 62500.0, -1743.0 / 31250.0, 0.25),
        (5012029.0 / 34652500.0, -654441.0 / 2922500.0, 174375.0 / 388108.0, 0.25),
        (15267082809.0 / 155376265600.0, -71443401.0 / 120774400.0, 730878875.0 / 902184768.0, 2285395.0 / 8070912.0, 0.25),
        (82889.0 / 524892.0, 0.0, 15625.0 / 83664.0, 69875.0 / 102672.0, -2260.0 / 8211.0, 0.25),
    ),
    b=(82889.0 / 524892.0, 0.0, 15625.0 / 83664.0, 69875.0 / 102672.0, -2260.0 / 8211.0, 0.25),
    order=4,
    b_embedded=(4586570599.0 / 29645900160.0, 0.0, 178811875.0 / 945068544.0, 814220225.0 / 1159782912.0, -3700637.0 / 11593932.0, 61727.0 / 225920.0),
    embedded_order=3,
)
ARK436L2SA_TABLEAU = ButcherTableauImex(
    explicit=ARK436L2SA_EXPLICIT,
    implicit=ARK436L2SA_IMPLICIT,
    short_name="ARK436L2SA",
    full_name="ARK4(3)6L[2]SA",
)
KENNEDY_CARPENTER43_6_TABLEAU = ARK436L2SA_TABLEAU


# Optional extension: adds human-readable scheme metadata and formatting helpers.
# Provides: with_scheme_display, display_tableau, short_name, full_name, __repr__, __str__, and __format__.
@with_scheme_display
# Optional extension: records accepted/rejected adaptive-step monitor events.
# Provides: call_monitored.
@with_adaptive_step_monitoring
class SchemeKennedyCarpenter43_6(SchemeKennedyCarpenterAdaptive):
    """Adaptive Kennedy-Carpenter ARK4(3)6L[2]SA IMEX method.

    Six-stage fourth-order additive Runge-Kutta pair using the shared
    Kennedy-Carpenter IMEX trial-step algorithm.
    """

    step_control: SchemeStepControl
    descriptor = SchemeDescriptor("KC43-6", "Kennedy-Carpenter 4(3) 6-stage")
    display_resolvent_problem = classmethod(imex_display_resolvent_problem)
    snapshot_state = imex_snapshot_state

    adaptivity = property(adaptive_adaptivity)

    tableau = KENNEDY_CARPENTER43_6_TABLEAU

    def __call__(self, interval: IntervalLike, state: State, executor: SchemeExecutor) -> float:
        return self.redirect_call(interval, state, executor)


__all__ = [
    "ARK436L2SA_EXPLICIT",
    "ARK436L2SA_IMPLICIT",
    "ARK436L2SA_TABLEAU",
    "KENNEDY_CARPENTER43_6_TABLEAU",
    "SchemeKennedyCarpenter43_6",
]
