from __future__ import annotations

"""
Gray-Scott accelerator comparison.

This example keeps the STARK-facing problem structure fixed and compares three
runtime accelerator choices:

- `AcceleratorAbsent()`
- `AcceleratorNumba()`
- `AcceleratorJax()`

The integration scheme, state type, allocator, and tolerances stay the same.
Only the derivative worker changes, via explicit construction, and the
comparison is run through STARK's ComparisonRunner framework.
"""

from dataclasses import dataclass

import numpy as np

from stark import Executor, Integrator, Interval, Marcher, ExecutorSafety, ExecutorTolerance
from stark.accelerators import AcceleratorAbsent, AcceleratorJax, AcceleratorNumba
from stark.algebraist.arity import AlgebraistArity
from stark.algebraist.generator import AlgebraistGeneratorGeneral
from stark.algebraist.layout import AlgebraistLayout, AlgebraistLayoutField
from stark.comparison import ComparisonRunner, ComparisonEntry, ComparisonProblem
from stark.schemes import SchemeDormandPrince

try:  # pragma: no cover - optional dependency
    import jax.numpy as jnp
except ImportError:  # pragma: no cover - optional dependency
    jnp = None


ALGEBRAIST_LAYOUT = AlgebraistLayout(
    fields=(
        AlgebraistLayoutField("du", "u"),
        AlgebraistLayoutField("dv", "v"),
    ),
)


@dataclass(slots=True)
class GrayScottParameters:
    grid_size: int = 96
    length: float = 2.5
    diffusivity_u: float = 2.0e-5
    diffusivity_v: float = 1.0e-5
    feed: float = 0.04
    kill: float = 0.06
    t_start: float = 0.0
    t_stop: float = 4.0
    initial_step: float = 1.0e-2
    atol: float = 1.0e-6
    rtol: float = 1.0e-5

    @property
    def dx(self) -> float:
        return self.length / self.grid_size

    @property
    def inv_dx2(self) -> float:
        return 1.0 / (self.dx * self.dx)


@dataclass(slots=True)
class GrayScottState:
    u: np.ndarray
    v: np.ndarray


class GrayScottTranslation:
    __slots__ = ("du", "dv")

    def __init__(self, du: np.ndarray, dv: np.ndarray) -> None:
        self.du = du
        self.dv = dv

    def __add__(self, other: GrayScottTranslation) -> GrayScottTranslation:
        return GrayScottTranslation(self.du + other.du, self.dv + other.dv)

    def __rmul__(self, scalar: float) -> GrayScottTranslation:
        return GrayScottTranslation(scalar * self.du, scalar * self.dv)

    def __call__(self, origin: GrayScottState, result: GrayScottState) -> None:
        result.u[...] = origin.u + self.du
        result.v[...] = origin.v + self.dv

    def norm(self) -> float:
        energy = np.dot(self.du.ravel(), self.du.ravel()) + np.dot(self.dv.ravel(), self.dv.ravel())
        return float(np.sqrt(energy / self.du.size))


class GrayScottAllocator:
    __slots__ = ("grid_size",)

    def __init__(self, grid_size: int) -> None:
        self.grid_size = grid_size
        if not hasattr(GrayScottTranslation, "linear_combine"):
            GrayScottTranslation.linear_combine = _generated_linear_combine(self)

    def allocate_state(self) -> GrayScottState:
        shape = (self.grid_size, self.grid_size)
        return GrayScottState(np.zeros(shape, dtype=np.float64), np.zeros(shape, dtype=np.float64))

    def copy_state(self, source: GrayScottState, out: GrayScottState) -> None:
        np.copyto(out.u, source.u)
        np.copyto(out.v, source.v)

    def allocate_translation(self) -> GrayScottTranslation:
        shape = (self.grid_size, self.grid_size)
        return GrayScottTranslation(np.zeros(shape, dtype=np.float64), np.zeros(shape, dtype=np.float64))


def _generated_linear_combine(allocator):
    provider = AlgebraistGeneratorGeneral(
        translation=allocator.allocate_translation(),
        allocator=allocator,
        layout=ALGEBRAIST_LAYOUT,
    )
    return tuple(provider.provide(AlgebraistArity(arity)) for arity in range(1, 13))


def _laplacian_numpy(field: np.ndarray, inv_dx2: float) -> np.ndarray:
    return (
        np.roll(field, 1, axis=0)
        + np.roll(field, -1, axis=0)
        + np.roll(field, 1, axis=1)
        + np.roll(field, -1, axis=1)
        - 4.0 * field
    ) * inv_dx2


def _gray_scott_rhs_numba(
    u,
    v,
    out_du,
    out_dv,
    diffusivity_u,
    diffusivity_v,
    feed,
    kill,
    inv_dx2,
):
    rows, cols = u.shape
    for i in range(rows):
        up = i - 1 if i > 0 else rows - 1
        down = i + 1 if i + 1 < rows else 0
        for j in range(cols):
            left = j - 1 if j > 0 else cols - 1
            right = j + 1 if j + 1 < cols else 0
            centre_u = u[i, j]
            centre_v = v[i, j]
            laplacian_u = (u[up, j] + u[down, j] + u[i, left] + u[i, right] - 4.0 * centre_u) * inv_dx2
            laplacian_v = (v[up, j] + v[down, j] + v[i, left] + v[i, right] - 4.0 * centre_v) * inv_dx2
            reaction = centre_u * centre_v * centre_v
            out_du[i, j] = diffusivity_u * laplacian_u - reaction + feed * (1.0 - centre_u)
            out_dv[i, j] = diffusivity_v * laplacian_v + reaction - (feed + kill) * centre_v


class GrayScottDerivative:
    __slots__ = ("parameters",)

    def __init__(self, parameters: GrayScottParameters) -> None:
        self.parameters = parameters

    def __call__(self, interval: Interval, state: GrayScottState, out: GrayScottTranslation) -> None:
        del interval
        parameters = self.parameters
        laplacian_u = _laplacian_numpy(state.u, parameters.inv_dx2)
        laplacian_v = _laplacian_numpy(state.v, parameters.inv_dx2)
        reaction = state.u * state.v * state.v
        out.du[:] = parameters.diffusivity_u * laplacian_u - reaction + parameters.feed * (1.0 - state.u)
        out.dv[:] = parameters.diffusivity_v * laplacian_v + reaction - (parameters.feed + parameters.kill) * state.v


class GrayScottNumbaDerivative:
    __slots__ = ("kernel", "parameters")

    def __init__(self, parameters: GrayScottParameters, accelerator: Accelerator) -> None:
        self.parameters = parameters
        self.kernel = accelerator.compile(_gray_scott_rhs_numba)
        probe = np.zeros((parameters.grid_size, parameters.grid_size), dtype=np.float64)
        accelerator.compile_examples(
            self.kernel,
            (
                probe,
                probe,
                probe,
                probe,
                parameters.diffusivity_u,
                parameters.diffusivity_v,
                parameters.feed,
                parameters.kill,
                parameters.inv_dx2,
            ),
        )

    def __call__(self, interval: Interval, state: GrayScottState, out: GrayScottTranslation) -> None:
        del interval
        parameters = self.parameters
        self.kernel(
            state.u,
            state.v,
            out.du,
            out.dv,
            parameters.diffusivity_u,
            parameters.diffusivity_v,
            parameters.feed,
            parameters.kill,
            parameters.inv_dx2,
        )


class GrayScottJaxDerivative:
    __slots__ = ("kernel", "parameters")

    @staticmethod
    def gray_scott_rhs_jax(u, v, diffusivity_u, diffusivity_v, feed, kill, inv_dx2):
        if jnp is None:  # pragma: no cover - guarded by availability checks
            raise RuntimeError("JAX is unavailable.")
        laplacian_u = (
            jnp.roll(u, 1, axis=0)
            + jnp.roll(u, -1, axis=0)
            + jnp.roll(u, 1, axis=1)
            + jnp.roll(u, -1, axis=1)
            - 4.0 * u
        ) * inv_dx2
        laplacian_v = (
            jnp.roll(v, 1, axis=0)
            + jnp.roll(v, -1, axis=0)
            + jnp.roll(v, 1, axis=1)
            + jnp.roll(v, -1, axis=1)
            - 4.0 * v
        ) * inv_dx2
        reaction = u * v * v
        du = diffusivity_u * laplacian_u - reaction + feed * (1.0 - u)
        dv = diffusivity_v * laplacian_v + reaction - (feed + kill) * v
        return du, dv

    def __init__(self, parameters: GrayScottParameters, accelerator: Accelerator) -> None:
        self.parameters = parameters
        self.kernel = accelerator.compile(self.gray_scott_rhs_jax)
        probe = np.zeros((parameters.grid_size, parameters.grid_size), dtype=np.float64)
        accelerator.compile_examples(
            self.kernel,
            (
                probe,
                probe,
                parameters.diffusivity_u,
                parameters.diffusivity_v,
                parameters.feed,
                parameters.kill,
                parameters.inv_dx2,
            ),
        )

    def __call__(self, interval: Interval, state: GrayScottState, out: GrayScottTranslation) -> None:
        del interval
        parameters = self.parameters
        du, dv = self.kernel(
            state.u,
            state.v,
            parameters.diffusivity_u,
            parameters.diffusivity_v,
            parameters.feed,
            parameters.kill,
            parameters.inv_dx2,
        )
        np.copyto(out.du, np.asarray(du))
        np.copyto(out.dv, np.asarray(dv))


def build_initial_state(parameters: GrayScottParameters) -> GrayScottState:
    shape = (parameters.grid_size, parameters.grid_size)
    u = np.ones(shape, dtype=np.float64)
    v = np.zeros(shape, dtype=np.float64)
    centre = parameters.grid_size // 2
    radius = parameters.grid_size // 8
    u[centre - radius : centre + radius, centre - radius : centre + radius] = 0.50
    v[centre - radius : centre + radius, centre - radius : centre + radius] = 0.25
    rng = np.random.default_rng(7)
    u += 0.01 * (rng.random(shape) - 0.5)
    v += 0.01 * (rng.random(shape) - 0.5)
    return GrayScottState(u, v)


def clone_state(state: GrayScottState) -> GrayScottState:
    return GrayScottState(state.u.copy(), state.v.copy())


def state_difference(left: GrayScottState, right: GrayScottState) -> float:
    du = left.u - right.u
    dv = left.v - right.v
    total = float(np.dot(du.ravel(), du.ravel()) + np.dot(dv.ravel(), dv.ravel()))
    size = du.size + dv.size
    return (total / size) ** 0.5


def state_diagnostics(state: GrayScottState) -> dict[str, float]:
    return {
        "mean_u": float(np.mean(state.u)),
        "mean_v": float(np.mean(state.v)),
        "max_u": float(np.max(state.u)),
        "max_v": float(np.max(state.v)),
    }


def build_solver(parameters: GrayScottParameters, accelerator: Accelerator):
    executor_safety = ExecutorSafety.fast()
    executor = Executor(
        tolerance=ExecutorTolerance(atol=parameters.atol, rtol=parameters.rtol),
        safety=executor_safety,
    )
    allocator = GrayScottAllocator(parameters.grid_size)
    derivative = build_derivative(parameters, accelerator)
    scheme = SchemeDormandPrince(derivative, allocator)
    marcher = Marcher(scheme, executor)
    integrate = Integrator(executor=executor)
    return marcher, integrate


def build_derivative(parameters: GrayScottParameters, accelerator: Accelerator):
    if accelerator.name == "numba":
        return GrayScottNumbaDerivative(parameters, accelerator)
    if accelerator.name == "jax":
        return GrayScottJaxDerivative(parameters, accelerator)
    return GrayScottDerivative(parameters)


class SolverPairBuilder:
    __slots__ = ("accelerator", "parameters", "_pending_integrator")

    def __init__(self, parameters: GrayScottParameters, accelerator: Accelerator) -> None:
        self.parameters = parameters
        self.accelerator = accelerator
        self._pending_integrator: Integrator | None = None

    def build_marcher(self):
        marcher, integrator = build_solver(self.parameters, self.accelerator)
        self._pending_integrator = integrator
        return marcher

    def build_integrator(self) -> Integrator:
        if self._pending_integrator is None:
            _marcher, integrator = build_solver(self.parameters, self.accelerator)
            return integrator
        integrator = self._pending_integrator
        self._pending_integrator = None
        return integrator


def build_entry(parameters: GrayScottParameters, accelerator: Accelerator) -> ComparisonEntry:
    pair_builder = SolverPairBuilder(parameters, accelerator)
    metadata = {
        "accelerator": accelerator.name,
    }
    if accelerator.name == "none":
        metadata["derivative"] = "vectorized NumPy derivative"
    elif accelerator.name == "numba":
        metadata["derivative"] = "compiled in-place loop kernel"
    elif accelerator.name == "jax":
        metadata["derivative"] = "pure JAX kernel via explicit construction"
    return ComparisonEntry(
        name=accelerator.name,
        build_marcher=pair_builder.build_marcher,
        build_integrator=pair_builder.build_integrator,
        metadata=metadata,
    )


def main() -> None:
    parameters = GrayScottParameters()
    available = [AcceleratorAbsent()]
    unavailable: list[str] = []
    for name, factory in (
        ("numba", AcceleratorNumba),
        ("jax", AcceleratorJax),
    ):
        try:
            available.append(factory())
        except ModuleNotFoundError:
            unavailable.append(name)

    if len(available) < 2:
        raise RuntimeError("Gray-Scott ComparisonRunner needs at least two available accelerators.")

    problem = ComparisonProblem(
        name="Gray-Scott accelerator comparison",
        description=(
            "Same STARK scheme, same state/allocator, and same tolerances.\n"
            "Only the derivative worker changes; each row constructs that worker explicitly.\n"
            "Scheme: Dormand-Prince adaptive explicit RK\n"
            f"Grid: {parameters.grid_size} x {parameters.grid_size}\n"
            f"Time interval: [{parameters.t_start}, {parameters.t_stop}]"
        ),
        build_state=lambda: build_initial_state(parameters),
        build_interval=lambda: Interval(parameters.t_start, parameters.initial_step, parameters.t_stop),
        difference=state_difference,
        diagnostics=state_diagnostics,
    )
    entries = [build_entry(parameters, accelerator) for accelerator in available]
    report = ComparisonRunner(problem, entries, repeats=3, prewarm_builders=False)()

    print(report.render())
    if unavailable:
        print()
        print("Skipped accelerators:")
        for name in unavailable:
            print(f"- {name}: backend unavailable")


if __name__ == "__main__":
    main()











