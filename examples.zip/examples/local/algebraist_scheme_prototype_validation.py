from __future__ import annotations

import numpy as np

from examples.comparison.fput.common import INITIAL_CONDITIONS, PROBLEM_PARAMETERS, TOLERANCE_PARAMETERS
from examples.comparison.fput.stark import ACCELERATOR, ALGEBRAIST, FPUTDerivative, FPUTState, FPUTAllocator
from stark import Executor, Integrator, Interval, Marcher, ExecutorSafety, ExecutorTolerance
from stark.algebraist.runtime import AlgebraistRuntimeSpecialist
from stark.comparison import ComparisonRunner, ComparisonEntry, ComparisonProblem
from stark.schemes.explicit.adaptive.cash_karp import SchemeCashKarp
from stark.schemes.explicit.adaptive.dormand_prince import SchemeDormandPrince
from stark.schemes.explicit.fixed.euler import SchemeEuler


LOCAL_PROBLEM_PARAMETERS = {
    **PROBLEM_PARAMETERS,
    "t1": 200.0,
}
LOCAL_TOLERANCE_PARAMETERS = {
    **TOLERANCE_PARAMETERS,
    "rtol": 1.0e-7,
    "atol": 1.0e-9,
}


def build_state() -> FPUTState:
    return FPUTState(
        INITIAL_CONDITIONS["q"].copy(),
        INITIAL_CONDITIONS["p"].copy(),
    )


def build_interval(*, step: float | None = None, stop: float | None = None) -> Interval:
    return Interval(
        LOCAL_PROBLEM_PARAMETERS["t0"],
        LOCAL_TOLERANCE_PARAMETERS["initial_step"] if step is None else step,
        LOCAL_PROBLEM_PARAMETERS["t1"] if stop is None else stop,
    )


def state_difference(left: FPUTState, right: FPUTState) -> float:
    dq = left.q - right.q
    dp = left.p - right.p
    return float(np.sqrt((np.dot(dq, dq) + np.dot(dp, dp)) / dq.size))


def diagnostics(state: FPUTState) -> dict[str, float]:
    return {
        "q_norm": float(np.sqrt(np.dot(state.q, state.q) / state.q.size)),
        "p_norm": float(np.sqrt(np.dot(state.p, state.p) / state.p.size)),
    }


def scheme_name(scheme_source) -> str:
    return getattr(scheme_source, "__name__", type(scheme_source).__name__)


def ExecutorTolerance() -> ExecutorTolerance:
    return ExecutorTolerance(
        atol=LOCAL_TOLERANCE_PARAMETERS["atol"],
        rtol=LOCAL_TOLERANCE_PARAMETERS["rtol"],
    )


def build_marcher(scheme_source, *, adaptive: bool) -> Marcher:
    allocator = FPUTAllocator(LOCAL_PROBLEM_PARAMETERS)
    derivative = FPUTDerivative(LOCAL_PROBLEM_PARAMETERS)
    executor_tolerance = ExecutorTolerance() if adaptive else ExecutorTolerance()
    executor = Executor(tolerance=executor_tolerance, safety=ExecutorSafety.fast())
    return Marcher(scheme_source(derivative, allocator), executor)


def build_integrator() -> Integrator:
    return Integrator(executor=Executor(safety=ExecutorSafety.fast()))


def build_cash_karp(derivative, allocator) -> SchemeCashKarp:
    return SchemeCashKarp(derivative, allocator)


def build_dormand_prince(derivative, allocator) -> SchemeDormandPrince:
    return SchemeDormandPrince(derivative, allocator)


def build_specialist(allocator):
    return AlgebraistRuntimeSpecialist(
        translation=allocator.allocate_translation(),
        allocator=allocator,
        linear_combine=ALGEBRAIST.linear_combine,
        accelerator=ACCELERATOR,
    )


def build_euler_specialist(derivative, allocator) -> SchemeEuler:
    return SchemeEuler(
        derivative,
        allocator,
        specialist=build_specialist(allocator),
    )


def build_cash_karp_specialist(derivative, allocator) -> SchemeCashKarp:
    return SchemeCashKarp(
        derivative,
        allocator,
        specialist=build_specialist(allocator),
    )


def build_dormand_prince_specialist(derivative, allocator) -> SchemeDormandPrince:
    return SchemeDormandPrince(
        derivative,
        allocator,
        specialist=build_specialist(allocator),
    )


def run_case(scheme_source, *, adaptive: bool, step: float | None = None, stop: float | None = None):
    state = build_state()
    interval = build_interval(step=step, stop=stop)
    marcher = build_marcher(scheme_source, adaptive=adaptive)
    integrate = Integrator(executor=marcher.executor)

    steps = 0
    for _interval, _state in integrate.live(marcher, interval, state):
        del _interval, _state
        steps += 1

    return state, interval.present, interval.step, steps


def compare(name: str, production, prototype, *, adaptive: bool, step: float | None = None, stop: float | None = None) -> None:
    production_result = run_case(production, adaptive=adaptive, step=step, stop=stop)
    prototype_result = run_case(prototype, adaptive=adaptive, step=step, stop=stop)

    production_state, production_time, production_step, production_steps = production_result
    prototype_state, prototype_time, prototype_step, prototype_steps = prototype_result

    np.testing.assert_allclose(prototype_state.q, production_state.q, rtol=1.0e-13, atol=1.0e-13)
    np.testing.assert_allclose(prototype_state.p, production_state.p, rtol=1.0e-13, atol=1.0e-13)
    np.testing.assert_allclose(prototype_time, production_time, rtol=0.0, atol=1.0e-14)
    np.testing.assert_allclose(prototype_step, production_step, rtol=1.0e-13, atol=1.0e-13)
    if prototype_steps != production_steps:
        raise AssertionError(f"{name} step count mismatch: {prototype_steps} != {production_steps}")

    print(
        f"{name}: ok; steps={prototype_steps}; "
        f"t={prototype_time:.12g}; next_dt={prototype_step:.12g}; "
        f"difference={state_difference(prototype_state, production_state):.3e}"
    )


def timing_comparison(
    name: str,
    production,
    prototype,
    *,
    adaptive: bool,
    repeats: int,
    step: float | None = None,
    stop: float | None = None,
    extra_prototypes: tuple[tuple[str, object], ...] = (),
) -> None:
    problem = ComparisonProblem(
        name=f"FPUT {name} prototype validation",
        build_state=build_state,
        build_interval=lambda: build_interval(step=step, stop=stop),
        difference=state_difference,
        diagnostics=diagnostics,
    )
    entries = [
        ComparisonEntry(
            "production",
            lambda: build_marcher(production, adaptive=adaptive),
            build_integrator=build_integrator,
            metadata={"scheme": scheme_name(production)},
        ),
        ComparisonEntry(
            "prototype",
            lambda: build_marcher(prototype, adaptive=adaptive),
            build_integrator=build_integrator,
            metadata={"scheme": scheme_name(prototype)},
        ),
    ]
    entries.extend(
        ComparisonEntry(
            label,
            lambda scheme_source=scheme_source: build_marcher(scheme_source, adaptive=adaptive),
            build_integrator=build_integrator,
            metadata={"scheme": scheme_name(scheme_source)},
        )
        for label, scheme_source in extra_prototypes
    )

    report = ComparisonRunner(problem, entries, repeats=repeats)()
    print(report.render())


def main() -> None:
    compare("Euler", SchemeEuler, build_euler_specialist, adaptive=False, step=1.0e-3, stop=2.0)
    compare("Cash-Karp", SchemeCashKarp, build_cash_karp_specialist, adaptive=True)
    compare("Dormand-Prince", SchemeDormandPrince, build_dormand_prince_specialist, adaptive=True)
    timing_comparison(
        "Euler",
        SchemeEuler,
        SchemeEuler,
        adaptive=False,
        repeats=3,
        step=1.0e-3,
        stop=2.0,
        extra_prototypes=(("specialist", build_euler_specialist),),
    )
    timing_comparison(
        "Cash-Karp",
        SchemeCashKarp,
        build_cash_karp,
        adaptive=True,
        repeats=3,
        extra_prototypes=(("specialist", build_cash_karp_specialist),),
    )
    timing_comparison(
        "Dormand-Prince",
        SchemeDormandPrince,
        build_dormand_prince,
        adaptive=True,
        repeats=3,
        extra_prototypes=(("specialist", build_dormand_prince_specialist),),
    )


if __name__ == "__main__":
    main()
