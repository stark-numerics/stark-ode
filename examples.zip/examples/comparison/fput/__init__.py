"""FPUT benchmark case."""








