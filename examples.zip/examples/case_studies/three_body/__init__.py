"""Structured three-body example."""
